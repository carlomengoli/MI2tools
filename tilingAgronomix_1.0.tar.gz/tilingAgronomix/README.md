Beta version of bgmm package
============================

The CRAN version is here:
http://cran.r-project.org/web/packages/bgmm/


Detailed description of this package is available in paper:
The R Package bgmm: Mixture Modeling with Uncertain Knowledge
Przemyslaw Biecek, Ewa Szczurek, Martin Vingron, Jerzy Tiuryn
JSS Vol. 47, Issue 3, Apr 2012
http://www.jstatsoft.org/v47/i03/

